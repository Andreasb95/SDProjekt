﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Kantine_bestilling_system.Annotations;

namespace Kantine_bestilling_system
{
    class ViewModel : INotifyPropertyChanged
    {
        public static ObservableCollection<Model> List { get; set; }

        public string Item { get; set; }
        public int Price { get; set; }
        public static int OrderNr { get; set; }

        public static int TotalPrice { get; set; }

        




        public ICommand AddCommand { get; set; }
        public ICommand Sandwich { get; set; }
        public ICommand Sandwich2 { get; set; }
        public ICommand Redbull { get; set; }
        public ICommand Vand { get; set; }
        public ICommand Juice { get; set; }



        public ViewModel()
        { 
            List = new ObservableCollection<Model>();
           LoadEventsAsync();

            
            AddCommand = new RelayCommand(Add);
            Sandwich = new RelayCommand(AddSandwich);
            Sandwich2 = new RelayCommand(AddSandwich2);
            Redbull = new RelayCommand(AddRedbull);
            Vand = new RelayCommand(AddVand);
            Juice = new RelayCommand(AddJuice);
        }


        public void Add()
        {
            List.Add(new Model("Skinke Sandwich",35));
            PersistencyService.SaveEventsAsJsonAsync(List);

        }

        public void AddSandwich()
        {
            List.Add(new Model("Kylling Sandwich",35));
            PersistencyService.SaveEventsAsJsonAsync(List);
        }

        public void AddSandwich2()
        {
            List.Add(new Model("Delle Sandwich",30));
            PersistencyService.SaveEventsAsJsonAsync(List);
        }

        public void AddRedbull()
        {
            List.Add(new Model("Redbull",10));
            PersistencyService.SaveEventsAsJsonAsync(List);
        }

        public void AddVand()
        {
            List.Add(new Model("KildeVæld",10));
            PersistencyService.SaveEventsAsJsonAsync(List);
        }

        public void AddJuice()
        {
            List.Add(new Model("Juice",15));
            PersistencyService.SaveEventsAsJsonAsync(List);
        }
        
        
        // Kan få den til at vise 35 men så heller ikke mere xD 
        public static int Totalpricee
        {
            get { return Model.Totalprice; }
            set { Model.Totalprice = value; }

        }
        

        public async void LoadEventsAsync()
        {
            var list = await PersistencyService.LoadEventsFromJsonAsync();
            if (list != null)
                foreach (var ev in list)
                {
                    List.Add(ev);
                }
            else
            {
                //Data til testformål
               // List.Add(new Model("TOast", 15));
                //List.Add(new Model("Juice", 8));
            }
        }



        #region MyRegion

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    } 
    #endregion
}
