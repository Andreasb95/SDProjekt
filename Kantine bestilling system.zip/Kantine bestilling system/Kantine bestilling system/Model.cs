﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kantine_bestilling_system
{
    class Model
    {
        
        public string Item { get; set; }
        public int Price  { get; set; }
        

        public Model(string item, int price)
        {
            Item = item;
            Price = price;
            Totalprice = price;
        }

        public static int Totalprice { get; set; } = 0;

        public override string ToString()
        {
            return $" Vare: {Item}, Pris: {Price}";
        }
    }
}
